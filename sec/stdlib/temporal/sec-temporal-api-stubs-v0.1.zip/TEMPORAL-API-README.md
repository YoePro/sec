# Sec `stdlib/temporal` API scaffold — draft 0.1

Created: 2026-10-16. This is a **source overlay** for an already existing Sec repository, not a replacement for your local directory structure.

## Install

The archive contains source files under `payload/sec/stdlib/temporal/` and **deliberately omits** `std-temporal.md`, which you already have.

Extract the archive to a temporary directory or your repository root (the `payload/` prefix avoids touching your source tree). From the directory holding `install_temporal_stubs.py`, run:

```bash
python install_temporal_stubs.py --root sec/stdlib/temporal --dry-run
python install_temporal_stubs.py --root sec/stdlib/temporal
```

The installer skips existing files; it does not overwrite anything unless you explicitly use `--overwrite`. Use the zip as a reference if your current folder structure differs.

## Contents and status

| Area | Sec source | Own rulebook | Status |
|---|---:|---|---|
| `calendar` | 3 | `calendar/std-temporal-calendar.md` | Provisional API; NotImplemented |
| `calendar` | 1 | `calendar/historical/std-temporal-calendar-historical.md` | Provisional API; NotImplemented |
| `arithmetic` | 2 | `arithmetic/std-temporal-arithmetic.md` | Provisional API; NotImplemented |
| `parse` | 1 | `parse/std-temporal-parse.md` | Provisional API; NotImplemented |
| `timezone` | 1 | `timezone/std-temporal-timezone.md` | Provisional API; NotImplemented |
| `business` | 2 | `business/std-temporal-business.md` | Provisional API; NotImplemented |
| `format` | 0 | Reserved child book | No API yet |
| `interval` | 0 | Reserved child book | No API yet |
| `recurrence` | 0 | Reserved child book | No API yet |
| `holiday` | 0 | Reserved child book | No API yet |
| `timescale` | 0 | Reserved child book | No API yet |
| `precision` | 0 | Reserved child book | No API yet |
| `astronomy` | 0 | Reserved child book | No API yet |
| `calendar/systems` | 0 | Reserved child book | No API yet |

## Guardrails

- The API is **provisional**, not a locked 0.1 interface. Compare and revise member-by-member before implementation.
- All fallible function stubs return a real `*.NotImplemented` error; no fabricated successful results.
- Never add `impl date`, `impl time`, `impl datetime` or `impl duration` outside `sec/core`.
- Sec duration conversion remains driven by its general unit system. `5<days>` and `1<week>` are units, not stdlib constructors.
- `CalendarPeriod` is calendar-relative, not elapsed `duration`.
- No implicit timezone, system locale, current clock, tzdb revision or holiday database.
- Source declarations match child books exactly; all enum/union members have preceding comments.
- **Not compiler-verified.** I could examine live repository source, but I cannot build against your uncommitted local compiler/tree. Basic static structural checks have been performed on the generated files.

## Next implementation sequence

Begin by verifying module/import resolution and error enum syntax with your current Sec compiler. Then complete Gregorian/Julian `calendar` algorithms and tests; progress to arithmetic and historical profile data. Avoid implementing long-horizon timestamp and time zone conversions until `Instant` and time scales have exact contracts.
