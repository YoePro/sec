#!/usr/bin/env python3
"""Safely overlay the Sec temporal draft API; default mode never overwrites files."""
import argparse
from pathlib import Path
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True, help='Path to repository sec/stdlib/temporal')
parser.add_argument('--dry-run', action='store_true', help='Preview planned writes')
parser.add_argument('--overwrite', action='store_true', help='Explicitly replace local conflicting files')
args=parser.parse_args()
src = Path(__file__).resolve().parent/'payload/sec/stdlib/temporal'
if not src.exists():
    parser.error('Extract the archive first: source folder payload/sec/stdlib/temporal not found next to script')
written=skipped=0
for file in sorted(src.rglob('*')):
    if not file.is_file(): continue
    dest = args.root/file.relative_to(src)
    if dest.exists() and not args.overwrite:
        print(f'SKIP existing: {dest}')
        skipped+=1
        continue
    mode='OVERWRITE' if dest.exists() else 'CREATE'
    print(f'{mode}: {dest}')
    if not args.dry_run:
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(file,dest)
    written+=1
print(f'Planned/written: {written}; skipped: {skipped}; dry-run: {args.dry_run}')
